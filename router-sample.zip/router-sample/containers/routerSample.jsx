import React, { Component } from "react";
import {  Route,  NavLink, Link, HashRouter, BrowserRouter as Router} from "react-router-dom";
import RouterHome from "../components/routerHome.jsx";
import RouterStuff from "../components/routerStuff.jsx";
import RouterContact from "../components/routerContact.jsx";
import './index.css';

class RouterSample extends Component {
  render() {
    return (
        // <HashRouter>
        // <Router>
            <div>
                <h1>Simple SPA</h1>
                <ul className="header">
                    <li><NavLink to="/">Home</NavLink></li>
                    <li><NavLink to="/stuff">Stuff</NavLink></li>
                    <li><NavLink to="/contact">Contact</NavLink></li>
                    {/* <li><NavLink to={{
                                pathname: '/courses.jsp',
                                search: '?sort=name',
                                hash: '#/order_detail_lookup'
                                }}>fff</NavLink> </li> */}
                </ul>
                <div className="content">
                    <Route path="/" component={RouterHome}/>
                    <Route path="/stuff" component={RouterStuff}/>
                    <Route path="/contact" component={RouterContact}/>
                    {/* <Route path="/order_detail_lookup" component={RouterContact}/> */}
                </div>
            </div>
        // </Router>
    //   </HashRouter>
    );
  }
}

export default RouterSample;