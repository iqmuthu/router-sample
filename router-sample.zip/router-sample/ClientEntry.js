import React from 'react';
import ReactDOM from 'react-dom';
import RouterSample from './containers/routerSample.jsx';
import { Provider } from 'react-redux';
import { BrowserRouter as Router, HashRouter} from "react-router-dom";
ReactDOM.render(
<HashRouter>
  <RouterSample />
</HashRouter>
, document.getElementById('personalExpenseNode')
);
